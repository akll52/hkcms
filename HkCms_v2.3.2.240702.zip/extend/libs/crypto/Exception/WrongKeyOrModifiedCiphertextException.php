<?php

namespace libs\crypto\Exception;

class WrongKeyOrModifiedCiphertextException extends \libs\crypto\Exception\CryptoException
{
}
