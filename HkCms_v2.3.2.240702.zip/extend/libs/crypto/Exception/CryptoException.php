<?php

namespace libs\crypto\Exception;

class CryptoException extends \Exception
{
}
