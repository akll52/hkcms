<?php

namespace libs\crypto\Exception;

class BadFormatException extends \libs\crypto\Exception\CryptoException
{
}
