<?php
return [
    // 提示
    'No permission to operate this column'  => '没有权限操作该栏目',
    'Column information does not exist'     => '栏目信息不存在',
    'Model information does not exist'      => '模型信息不存在',
];