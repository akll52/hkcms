<?php
return [
    'Please select the left column' => '请选择左侧栏目'
];