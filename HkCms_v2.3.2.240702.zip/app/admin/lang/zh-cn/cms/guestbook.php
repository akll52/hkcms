<?php
return [
    'All'                               => '全部',
    'Check'                             => '查阅',
    'Unread'                            => '未读',
    'Have read'                         => '已读',
    'View time'                         => '查看时间',
    'Column'                            => '所属栏目',
    'A total of %s page %s data'        => '共 %s 页 %s 条数据',
    'Column information does not exist' => '栏目信息不存在',
    'Model information does not exist'  => '模型信息不存在',
    'No permission to operate this column'  => '没有权限操作该栏目',
];