<?php
return [
    // 字段
    'Username'       => '用户名',
    'Password'       => '密码',
    'Captcha'        => '验证码',

    // 提示
    'Captcha error'                            => '验证码错误',
    'Login successfully'                       => '登录成功',
    'Account is disabled'                      => '账户已被禁用',
    'Username or password error, login failed' => '用户名或密码错误，登录失败',
    'Too many errors. Please try again later' => '错误次数过多，请稍后再试',
];