<?php
return [
    'Sharding is turned off'          => '分片功能已关闭',
    'No files uploaded'               => '没有文件上传',
];