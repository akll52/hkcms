<?php
return [
    'Content' => '内容',
    'Operating time' => '操作时间',
    'Username' => '用户名',
    'Nickname' => '昵称',
    'Default action' => '默认操作'
];