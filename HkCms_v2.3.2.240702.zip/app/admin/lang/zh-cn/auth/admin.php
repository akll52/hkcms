<?php
return [
    // 字段
    'Owned role' => '所属角色',
    'Username' => '用户名',
    'Nickname' => '昵称',
    'Login time' => '登录时间',
    'Remark' => '备注',
    'Avatar' => '头像',
    'Email' => '邮箱',
    'Password' => '密码',
    'Login ip' => '登录IP',

    // 提示
    'The role group to which it belongs cannot be empty' => '所属角色组不能为空'
];