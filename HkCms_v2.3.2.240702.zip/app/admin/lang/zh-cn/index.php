<?php
return [
    'Username'  => '用户名',
    'Nickname'  => '昵称',
    'Email'     => '邮箱',
    'Password'  => '密码',
    'Local Upload and Upgrade'  => '本地上传更新',
    'Cache closed'  => '缓存已关闭',
    'Cache is on'  => '缓存已开启',

    // 提示
    'Server connection failed'                               => '服务器连接失败',
    'The current content editing mode has changed to 【%s】.' => '当前内容编辑模式已更改为【%s】。'
];