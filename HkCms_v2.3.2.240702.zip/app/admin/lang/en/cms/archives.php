<?php

return [
    // 模型字段
    'subtitle' => 'Subhead',
    'diyname' => 'Custom URL',
    'iscomment' => 'Comment switch',
    'islogin' => 'Login',
    'publish_time' => 'Release time',
    'show_tpl' => 'Page',

    // 自定义字段语言包继续往下写，'字段名'=>'英文'
];